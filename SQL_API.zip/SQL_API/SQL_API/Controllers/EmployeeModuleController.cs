﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using SQL_API.Models;
using Microsoft.Data.SqlClient;
using System.Reflection.PortableExecutable;


namespace SQL_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeModuleController:ControllerBase
    {
        private readonly DataContext _context;
        public EmployeeModuleController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("Getallempdetails")]
        public async Task<IActionResult> Getallempdetails()
        {
            var cmd = "SELECT * FROM Employee";
            var employees = new List<EmployeeModel>();
            using (var connection = _context.CreateConnectionCompany())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);
                using (var reader = await command.ExecuteReaderAsync())
                    while (await reader.ReadAsync())
                    {
                        var employee = new EmployeeModel
                        {
                            id = reader.GetInt32(reader.GetOrdinal("Id")),
                            name = reader.GetString(reader.GetOrdinal("name")),
                            designation = reader.GetString(reader.GetOrdinal("designation")),
                            department = reader.GetString(reader.GetOrdinal("department")),

                        };
                        employees.Add(employee);
                    }
            }
            return Ok(employees);
        }
        [HttpGet("Searchbydept/{dep}")]
        public async Task<IActionResult> Searchbydept([FromRoute] string dep)
        {
            var cmd = "SELECT * FROM Employee where department=@depart";
            var employees = new List<EmployeeModel>();
            using (var connection = _context.CreateConnectionCompany())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);
                command.Parameters.AddWithValue("@depart", dep);
                using (var reader = await command.ExecuteReaderAsync())
                    while (await reader.ReadAsync())
                    {
                        var employee = new EmployeeModel
                        {
                            id = reader.GetInt32(reader.GetOrdinal("Id")),
                            name = reader.GetString(reader.GetOrdinal("name")),
                            designation = reader.GetString(reader.GetOrdinal("designation")),
                            department = reader.GetString(reader.GetOrdinal("department")),

                        };
                        employees.Add(employee);
                    }
            }
            return Ok(employees);
        }
        [HttpPost("InsertEmployee")]
        public async Task<dynamic> InsertEmployee([FromBody] EmployeeModel employee)
        {
            var cmd = "INSERT INTO Employee (Id, Name,designation,department) VALUES (@id, @name,@designation,@department)"; // Use a parameterized query

            using (var connection = _context.CreateConnectionCompany())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@id", employee.id);
                command.Parameters.AddWithValue("@name", employee.name);
                command.Parameters.AddWithValue("@designation", employee.designation);
                command.Parameters.AddWithValue("@department", employee.department);

                // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully inserted";
                }
                else
                {
                    return BadRequest("Failed to Insert employee");
                }
            }
        }
        [HttpPut("ModifyEmployee")]

        public async Task<dynamic> ModifyEmployee([FromBody] EmployeeModel employee)
        {
            if (employee == null || string.IsNullOrWhiteSpace(employee.name))
            {
                return BadRequest("Invalid employee data.");
            }

            var cmd = "UPDATE Employee SET  Name=@name,designation=@designation,department=@department WHERE Id=@id"; // Use a parameterized query

            using (var connection = _context.CreateConnectionCompany())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@id", employee.id);
                command.Parameters.AddWithValue("@name", employee.name);
                command.Parameters.AddWithValue("@designation", employee.designation);
                command.Parameters.AddWithValue("@department", employee.department);

                //        // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                //        // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully updated";
                }
                else
                {
                    return BadRequest("Failed to Modify employee.");
                }
            }
        }
        [HttpDelete("RemoveEmployee", Name = "RemoveEmployee")]
        public async Task<dynamic> RemoveEmployee([FromBody] EmployeeModel employee)
        {
            if (employee == null || string.IsNullOrWhiteSpace(employee.name))
            {
                return BadRequest("Invalid employee data.");
            }

            var cmd = "DELETE FROM Employee WHERE  Name=@name AND Id=@id"; // Use a parameterized query

            using (var connection = _context.CreateConnectionCompany())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@id", employee.id);
                command.Parameters.AddWithValue("@name", employee.name);

                // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully deleted";
                }
                else
                {
                    return BadRequest("Failed to Remove employee");
                }

            }
        }

    }

}

﻿using Microsoft.AspNetCore.Mvc;
using SQL_API.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace SQL_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly DataContext _context;
        public StudentController(DataContext context)
        {
            _context = context;
        }

    [HttpGet("Getallstuddetails")]
        public async Task<IActionResult> Getallstuddetails()
        {

            var cmd = "SELECT * FROM STUDENT";
            var students = new List<StudentModel>(); // Assuming EmployeeModel is your model class
            using (var connection = _context.CreateConnectionStudent())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);
                using (var reader = await command.ExecuteReaderAsync())
                    while (await reader.ReadAsync())
                    {
                        var student = new StudentModel
                        {
                            REGNO = reader.GetInt32(reader.GetOrdinal("REGNO")),
                            NAME = reader.GetString(reader.GetOrdinal("Name")),
                            EMAIL = reader.GetString(reader.GetOrdinal("EMAIL")),
                            PHONE = reader.GetString(reader.GetOrdinal("PHONE")),
                            DEPARTMENT = reader.GetString(reader.GetOrdinal("DEPARTMENT")),
                            // Map other properties as needed
                        };
                        students.Add(student);
                    }
            }
            // Return the list of employees as a JSON result
            return Ok(students);
            //return Json("Test response");
        }
        [HttpGet("Searchbyregno/{regno}")]
        public async Task<IActionResult> Searchbyregno([FromRoute] string regno)
        {
            var cmd = "SELECT * FROM Student WHERE regno = @regno";
            // Use a parameterized query
            var students = new List<StudentModel>(); // Assuming EmployeeModel is your model class

            using (var connection = _context.CreateConnectionStudent())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameter to the command
                command.Parameters.AddWithValue("@regno", regno);

                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var student = new StudentModel
                        {
                            REGNO = reader.GetInt32(reader.GetOrdinal("regno")),
                            NAME = reader.GetString(reader.GetOrdinal("Name")),
                            EMAIL = reader.GetString(reader.GetOrdinal("EMAIL")),
                            PHONE = reader.GetString(reader.GetOrdinal("PHONE")),
                            DEPARTMENT = reader.GetString(reader.GetOrdinal("DEPARTMENT")),
                            // Map other properties as needed
                        };
                        students.Add(student);
                    }
                }
            }

            return Ok(students);
        }
        [HttpPost("InsertStudent")]
        public async Task<dynamic> InsertStudent([FromBody] StudentModel student)
        {
            var cmd = "INSERT INTO student (regno, Name,EMAIL,PHONE,DEPARTMENT) VALUES (@regno, @name,@email,@phone,@department)"; // Use a parameterized query

            using (var connection = _context.CreateConnectionStudent())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@regno", student.REGNO);
                command.Parameters.AddWithValue("@name", student.NAME);
                command.Parameters.AddWithValue("@email", student.EMAIL);
                command.Parameters.AddWithValue("@phone", student.PHONE);
                command.Parameters.AddWithValue("@department", student.DEPARTMENT);
                // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully inserted";
                }
                else
                {
                    return BadRequest("Failed to Insert employee");
                }
            }
        }
        [HttpPut("ModifyStudent")]

        public async Task<dynamic> ModifyStudent([FromBody] StudentModel student)
        {
            if (student == null || string.IsNullOrWhiteSpace(student.NAME))
            {
                return BadRequest("Invalid student data.");
            }

            var cmd = "UPDATE student SET  Name=@name,email=@email,phone=@phone,department=@department WHERE regno=@regno"; // Use a parameterized query

            using (var connection = _context.CreateConnectionStudent())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@regno", student.REGNO);
                command.Parameters.AddWithValue("@name", student.NAME);
                command.Parameters.AddWithValue("@email", student.EMAIL);
                command.Parameters.AddWithValue("@phone", student.PHONE);
                command.Parameters.AddWithValue("@department", student.DEPARTMENT);

                //        // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                //        // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully updated";
                }
                else
                {
                    return BadRequest("Failed to Modify employee.");
                }
            }
        }
        [HttpDelete("RemoveStudent", Name = "RemoveStudent")]
        public async Task<dynamic> RemoveStudent([FromBody] StudentModel student)
        {
            if (student == null || string.IsNullOrWhiteSpace(student.NAME))
            {
                return BadRequest("Invalid student data.");
            }

            var cmd = "DELETE FROM student WHERE  Name=@name AND regno=@regno"; // Use a parameterized query

            using (var connection = _context.CreateConnectionStudent())
            {
                await connection.OpenAsync();
                using var command = new SqlCommand(cmd, connection);

                // Add the parameters to the command
                command.Parameters.AddWithValue("@regno", student.REGNO);
                command.Parameters.AddWithValue("@name", student.NAME);

                // Execute the command
                int rowsAffected = await command.ExecuteNonQueryAsync();

                // Check if the insert was successful
                if (rowsAffected > 0)
                {
                    return "Successfully deleted";
                }
                else
                {
                    return BadRequest("Failed to Remove student");
                }

            }
        }
        [HttpPost("Insertimage")]
        public async Task<IActionResult> UploadImage([FromForm] ImageReqDto imageReqDto)
        {
            if (imageReqDto.image == null || string.IsNullOrEmpty(imageReqDto.flag))
            {
                return BadRequest("Image and Flag are required.");
            }

            byte[] imageData;
            using (var memoryStream = new MemoryStream())
            {
                await imageReqDto.image.CopyToAsync(memoryStream);
                imageData = memoryStream.ToArray();
            }

            // using (var connection = new SqlConnection(_connectionString))
            using (var connection = _context.CreateConnectionCompany())

            {
                using (var command = new SqlCommand("InsertImage", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Flag", imageReqDto.flag);
                    command.Parameters.AddWithValue("@Image", imageData);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }
            }

            return Ok("Image uploaded successfully.");
        }

        [HttpGet("Getimage/{id}")]
        public async Task<IActionResult> GetImage(int id)
        {
            byte[] imageData = null;
            string flag = null;

            //using (var connection = new SqlConnection(_connectionString))
            using (var connection = _context.CreateConnectionCompany())

            {
                using (var command = new SqlCommand("GetImageById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", id);

                    await connection.OpenAsync();
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            flag = reader["Flag"] as string;
                            imageData = reader["Image"] as byte[];
                        }
                    }
                }
            }

            if (imageData == null)
            {
                return NotFound("Image not found.");
            }

            return File(imageData, "image/jpeg"); // Adjust the content type as needed
        }


        //UPDATE IMAGE
        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateImage(int id, [FromForm] ImageReqDto imageReqDto)
        {
            if (imageReqDto.image == null || string.IsNullOrEmpty(imageReqDto.flag))
            {
                return BadRequest("Image and Flag are required.");
            }

            byte[] imageData;
            using (var memoryStream = new MemoryStream())
            {
                await imageReqDto.image.CopyToAsync(memoryStream);
                imageData = memoryStream.ToArray();
            }

            //using (var connection = new SqlConnection(_connectionString))
            using (var connection = _context.CreateConnectionCompany())

            {
                using (var command = new SqlCommand("UpdateImage", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Flag", imageReqDto.flag);
                    command.Parameters.AddWithValue("@Image", imageData);

                    await connection.OpenAsync();
                    int rowsAffected = await command.ExecuteNonQueryAsync();

                    if (rowsAffected == 0)
                    {
                        return NotFound("Image not found.");
                    }
                }
            }

            return Ok("Image updated successfully.");
        }

    }
}

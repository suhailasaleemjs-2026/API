﻿namespace SQL_API.Controllers
{
    internal class _context
    {
    }
}
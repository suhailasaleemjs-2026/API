﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;


namespace SQL_API
{
    public class DataContext:DbContext
    {
        private readonly string _connectionstring;
        public DataContext(IConfiguration configuration)
        {
            _connectionstring = configuration.GetConnectionString
                ("SQLConnection");
            _connectionstring = configuration.GetConnectionString
                ("SQLConnection1");
        }
        public SqlConnection CreateConnectionCompany()
        {
            return new SqlConnection(_connectionstring);
        }
        public SqlConnection CreateConnectionStudent()
        {
            return new SqlConnection (_connectionstring);
        }
    }

}

﻿namespace SQL_API.Models
{
    public class EmployeeModel
    {
        public int id {  get; set; }
        public string name { get; set; }
        public string designation { get; set; }
        public string department { get; set; }

    }
}

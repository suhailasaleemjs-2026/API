﻿namespace SQL_API.Models
{
    public class StudentModel
    {
        public int REGNO { get; set; }
        public string NAME { get; set; }
        public string EMAIL { get; set; }
        public string PHONE { get; set; }
        public string DEPARTMENT { get; set; }
    }
}

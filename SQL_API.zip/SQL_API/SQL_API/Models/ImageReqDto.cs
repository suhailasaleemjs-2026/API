﻿namespace SQL_API.Models
{
    public class ImageReqDto
    {
        public string flag { get; set; }
        public int id { get; set; }
        public IFormFile image { get; set; }
    }
}
